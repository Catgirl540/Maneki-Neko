---
id: "kb-bills"
title: "账单、回单与导出"
navigation: "账户"
routes: ["/analysis", "/transactions/:id"]
keywords: ["账单", "流水", "回单", "CSV"]
sources: ["app/src/pages/BillsPage.tsx", "app/src/pages/TransactionDetailPage.tsx", "app/src/api/mock/index.ts", "framework/packages/bank-demo/src/http-tools.ts"]
---

## 在哪里看账单和搜索流水？ {#list}

进入「账户 → 账单」选择账户，按页面日期、分类、关键词筛选交易。助手可查询当前账户流水，支持关键词与最近条数，一次最多二十条；暂不支持按上个月等月份、日期范围或分类做完整分页查询。查不到不能等同于没有发生交易。

## 怎么查看交易详情与转账状态？ {#detail}

在账单点击一笔交易，查看交易详情、金额、交易双方、流水号与状态。助手可按交易编号查询详情；只能报告接口返回状态，不能把提交成功、预计到账或受理中说成已到账。

## 电子回单怎么下载？ {#receipt}

从「账户 → 账单 → 交易详情」点击「下载电子回单」。有下载地址时直接下载；当前演示部署没有服务端 PDF 地址，会改用浏览器打印，在打印框选择另存为 PDF。助手暂不能生成或下载回单。

## 怎么导出交易流水？支持 Excel 吗？ {#export}

在「账户 → 账单」打开导出功能，设置日期、分类、关键词后下载 CSV 文件，可用表格软件打开。文件包含实际筛选记录及相应字段，空结果不能伪造流水。当前不是原生 Excel 文件，助手暂不能导出。
